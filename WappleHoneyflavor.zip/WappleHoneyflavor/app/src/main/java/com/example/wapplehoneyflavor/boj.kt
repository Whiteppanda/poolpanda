package com.example.exercise

class boj(val question:String, val answer:String)